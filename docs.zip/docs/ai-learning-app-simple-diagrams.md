# AI Learning App Simple Diagrams

These diagrams give a high-level view of the AI Learning App using the current React frontend and FastAPI backend structure. They intentionally skip low-level APIs, tables, and implementation details so new developers and product stakeholders can understand the main flows quickly.

## 1. System Architecture Overview

```mermaid
flowchart LR
  Learner["Learner"]
  Admin["Admin"]
  Frontend["React Frontend"]
  Backend["FastAPI Backend"]
  Database[("PostgreSQL")]
  AI["AI / LLM Service"]

  Learner --> Frontend
  Admin --> Frontend
  Frontend --> Backend
  Backend --> Database
  Backend --> AI
  AI --> Backend
  Backend --> Frontend
```

The learner and admin both use the React frontend.
The frontend calls the FastAPI backend through the shared API client.
The backend stores application data in PostgreSQL.
AI features are handled through the backend, which calls the configured LLM service.

## 2. Learner Journey

```mermaid
flowchart LR
  Login["Login"]
  Dashboard["Dashboard"]
  Assigned["Assigned Assessment"]
  Attempt["Assessment Attempt"]
  Results["Results"]
  LearningPath["Learning Path"]

  Login --> Dashboard
  Dashboard --> Assigned
  Assigned --> Attempt
  Attempt --> Results
  Results --> LearningPath
```

Learners log in with candidate credentials created by an admin.
After login, they can view dashboard information and assigned assessments.
During an assessment, answers and progress are saved by the backend.
After submission, results can lead to a personalized learning path.

## 3. Admin Workflow

```mermaid
flowchart LR
  AdminLogin["Admin Login"]
  Candidates["Candidate Management"]
  Assessment["Assessment Creation"]
  Assignment["Learning Path Assignment"]
  Review["Results Review"]

  AdminLogin --> Candidates
  Candidates --> Assessment
  Assessment --> Review
  Review --> Assignment
```

Admins authenticate through the same login flow, with admin access checked by email.
They can create and manage candidates, including candidate credentials.
Admins create assessments, review submissions, adjust scoring, and publish feedback.
Final learning paths can be pushed to employees after results are reviewed.

## 4. Resume / JD Analysis Flow

```mermaid
flowchart LR
  Resume["Resume Upload"]
  JD["JD Upload"]
  SkillExtraction["Skill Extraction"]
  JDAnalysis["JD Analysis"]
  Gap["Skill Match / Gap Analysis"]
  Recommendation["Learning Path Recommendation"]

  Resume --> SkillExtraction
  JD --> JDAnalysis
  SkillExtraction --> Gap
  JDAnalysis --> Gap
  Gap --> Recommendation
```

The backend extracts text from uploaded PDF, DOCX, TXT, and related document formats.
Resume and JD analysis uses the skill intelligence service with an LLM-first flow.
The extracted skills include source, priority, confidence, proficiency, and JD matching.
Learning recommendations are based on gaps, assessment outcomes, and course catalog search.

## 5. Assessment Flow

```mermaid
flowchart LR
  Create["Assessment Creation"]
  Questions["Question Generation"]
  Assign["Assignment"]
  Submit["User Submission"]
  Evaluate["Evaluation"]
  Results["Results"]

  Create --> Questions
  Questions --> Assign
  Assign --> Submit
  Submit --> Evaluate
  Evaluate --> Results
```

Admins create assessments from required skills, role details, and optional uploaded documents.
The backend generates question sets using AI, with optional RAG grounding.
Candidates receive assigned assessments and submit answers through the quiz flow.
MCQs are auto-evaluated, while long-form answers can be reviewed and adjusted by admins.

## 6. AI Integration Flow

```mermaid
flowchart LR
  Frontend["Frontend"]
  Backend["Backend"]
  AIService["AI Service"]
  Validation["Validation / Fallback"]
  Response["Response"]
  User["User"]

  Frontend --> Backend
  Backend --> AIService
  AIService --> Validation
  Validation --> Response
  Response --> Backend
  Backend --> Frontend
  Frontend --> User
```

The frontend never calls the LLM directly.
FastAPI prepares prompts for skill extraction, question generation, feedback, and recommendations.
The backend validates AI output and uses fallbacks where supported.
Only cleaned, structured responses are returned to the frontend.

## Quick Module Map

- Frontend: React routes and containers in `FE/src`, with API calls centralized in `FE/src/API/services.ts`.
- Backend: FastAPI application in `BE/app/main.py`, with feature routes under `BE/app/api`.
- AI: LLM configuration in `BE/app/core/llm.py`, skill extraction in `BE/app/services/skill_intelligence.py`, and question generation in `BE/app/utils/generate_admin_assessment.py`.
- Data: SQLAlchemy models in `BE/app/db/models.py`, backed by PostgreSQL.
- Learning paths: Recommendation and assignment flow in `BE/app/api/learning_path.py`.
