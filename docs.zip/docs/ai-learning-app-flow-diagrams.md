# AI Learning App Flow Diagrams

This document describes the current end-to-end architecture and workflow of the AI Learning App based on the FastAPI backend and React frontend in this repository.

## High-Level Architecture

```mermaid
flowchart LR
  subgraph Learner["Learner / Candidate"]
    L1["Login"]
    L2["Dashboard"]
    L3["Assigned Assessments"]
    L4["Quiz / Assessment"]
    L5["Results and Learning Path"]
  end

  subgraph Admin["Admin"]
    A1["Admin Login"]
    A2["Candidate Management"]
    A3["Assessment Setup"]
    A4["Question Review"]
    A5["Results Review"]
    A6["Learning Path Assignment"]
    A7["Reports / Stats"]
  end

  subgraph Frontend["React Frontend"]
    F1["Public Landing"]
    F2["Auth Routes"]
    F3["Protected App Routes"]
    F4["Admin Routes"]
    F5["Axios API Client"]
    F6["Local Token Store"]
    F7["GET Cache"]
    F8["401 Handler"]
  end

  subgraph Backend["FastAPI Backend"]
    B1["Auth API"]
    B2["Candidate API"]
    B3["Assessment API"]
    B4["QuestionSet Test API"]
    B5["Assessment Results API"]
    B6["Learning Path API"]
    B7["Upload and Document API"]
    B8["Admin Skill Extraction API"]
    B9["Question Docs / RAG API"]
    B10["Dashboard / Admin Stats API"]
    B11["Middleware: CORS, GZip, Request ID, Logging"]
    B12["Exception Handlers"]
  end

  subgraph AILayer["AI Layer"]
    AI1["OpenAI Chat Model via LangChain"]
    AI2["Skill Intelligence Service"]
    AI3["Assessment Question Generator"]
    AI4["Session Feedback Generator"]
    AI5["FAISS Course Search"]
    AI6["HuggingFace Embeddings"]
    AI7["Regex / Dictionary Fallback"]
    AI8["Document RAG Index"]
  end

  subgraph Data["Data and Storage"]
    D1[("PostgreSQL")]
    D2[("Refresh Tokens")]
    D3[("Users and Candidates")]
    D4[("Assessments and Applications")]
    D5[("QuestionSets and Questions")]
    D6[("TestSessions and Answers")]
    D7[("LearningPaths")]
    D8[("UploadedDocuments")]
    D9[("AssessmentProgress")]
    D10[("Question and Session Feedback")]
    D11[("Course Master Excel")]
    D12[("FAISS Index Files")]
    D13[("S3 / MinIO Object Storage")]
    D14[("Redis / Celery Task State")]
  end

  subgraph External["External Integrations"]
    E1["Azure AD SSO"]
    E2["OpenAI API"]
    E3["Brevo SMTP Email"]
    E4["Sentry"]
    E5["Prometheus Metrics"]
  end

  L1 --> F2
  A1 --> F2
  F5 --> B11
  B11 --> B1
  B11 --> B2
  B11 --> B3
  B11 --> B4
  B11 --> B5
  B11 --> B6
  B11 --> B7
  B11 --> B8
  B11 --> B9
  B11 --> B10
  B1 --> D1
  B2 --> D1
  B3 --> D1
  B4 --> D1
  B5 --> D1
  B6 --> D1
  B7 --> D1
  B8 --> AI2
  B9 --> AI8
  B3 --> AI3
  B5 --> AI4
  B6 --> AI5
  AI1 --> E2
  AI2 --> AI1
  AI3 --> AI1
  AI4 --> AI1
  AI5 --> AI6
  AI5 --> D11
  AI5 --> D12
  AI8 --> D12
  B7 --> D13
  B9 --> D13
  B1 --> E1
  B1 --> E3
  B12 --> E4
  B11 --> E5
  B12 --> F5
  F8 --> F2
```

### Architecture Notes

- The frontend is a React/Vite app with protected learner routes and admin-only routes.
- The backend is a FastAPI app with JWT authentication, route-level dependencies, centralized middleware, logging, metrics, and exception handling.
- PostgreSQL stores the core application state: users, candidates, assessments, questions, sessions, answers, progress, feedback, and learning paths.
- S3/MinIO stores uploaded documents. Uploaded files can also be text-extracted and saved as `UploadedDocument` or `JobDescription` records.
- OpenAI is used through LangChain for skill extraction, question generation, and admin feedback generation.
- RAG support uses isolated document FAISS indexes for admin-uploaded question documents.
- Course recommendations use a FAISS course index when available and always fall back to the latest Excel course masterdata.
- Redis/Celery are configured for async/task patterns. OTP verification is currently disabled when Redis is unavailable.

## Detailed End-to-End Workflow

```mermaid
flowchart TD
  subgraph UserLane["User / Learner Swimlane"]
    U0["Open app"]
    U1["Login with candidate credentials"]
    U2["View learner dashboard"]
    U3["Open assigned assessment"]
    U4["Complete screening questions"]
    U5["Start assessment"]
    U6["Answer MCQ / coding / architecture / scenario questions"]
    U7["Auto-save progress"]
    U8["Submit assessment"]
    U9["View result"]
    U10["Request or view learning path"]
    U11["Consume recommended courses"]
  end

  subgraph AdminLane["Admin Swimlane"]
    AD0["Admin login"]
    AD1["Create or update candidate"]
    AD2["Upload JD / resume / requirements"]
    AD3["Extract skills and role"]
    AD4["Configure assessment"]
    AD5["Upload RAG document"]
    AD6["Generate assessment questions"]
    AD7["Publish assessment"]
    AD8["Review candidate sessions"]
    AD9["Override answer scoring if needed"]
    AD10["Generate and edit AI feedback"]
    AD11["Push learning path to employee"]
    AD12["Monitor stats and reports"]
  end

  subgraph FrontendLane["Frontend Swimlane"]
    FE0["React Router"]
    FE1{"Protected route?"}
    FE2["Login form"]
    FE3["Store access token, refresh token, role, candidate_id"]
    FE4["Axios request interceptor adds Bearer token"]
    FE5["Assessment setup UI"]
    FE6["Candidate assessment UI"]
    FE7["Quiz timer and progress state"]
    FE8["Results / learning path UI"]
    FE9{"HTTP 401?"}
    FE10["Clear local storage and redirect to /login"]
  end

  subgraph BackendLane["Backend API Swimlane"]
    BE0["FastAPI middleware adds request_id and logs"]
    BE1["/api/v1/auth/login"]
    BE2["Validate default admin or candidate password"]
    BE3{"Credentials valid?"}
    BE4["Create JWT pair"]
    BE5["Persist refresh token"]
    BE6["Update login streak"]
    BE7["get_current_user decodes access token"]
    BE8{"Role authorized?"}
    BE9["/api/v1/candidates"]
    BE10["/api/v1/admin/extract-skills*"]
    BE11["/api/v1/admin/question-docs/upload"]
    BE12["/api/v1/assessments"]
    BE13["/api/v1/assessments/{id}"]
    BE14["/api/v1/questionset-tests/start"]
    BE15["/api/v1/questionset-tests/submit"]
    BE16["/api/v1/assessment-progress/save"]
    BE17["/api/v1/admin/assessment-results/*"]
    BE18["/api/v1/learning-path/{session_id}"]
    BE19["/api/v1/learning-path/push-to-employee"]
    BE20["Standard HTTP error response"]
    BE21["/api/v1/dashboard and /api/v1/candidates/my-*"]
  end

  subgraph AILane["AI Layer Swimlane"]
    AI0["Text extraction"]
    AI1["Skill intelligence prompt"]
    AI2{"LLM extraction succeeds?"}
    AI3["Retry JSON repair up to configured attempts"]
    AI4["Regex / dictionary fallback"]
    AI5["Normalized role, skill, level, priority, confidence"]
    AI6["Question generation prompt"]
    AI7{"RAG context available?"}
    AI8["Use isolated document chunks"]
    AI9["Fall back to LLM-only batch"]
    AI10["Parse strict JSON question output"]
    AI11{"Question JSON valid and count exact?"}
    AI12["Persist generated questions"]
    AI13["Session feedback prompt"]
    AI14{"LLM feedback succeeds?"}
    AI15["Fallback feedback summary"]
    AI16["Course recommendation search"]
    AI17{"FAISS usable and current?"}
    AI18["Vector search"]
    AI19["Excel keyword fallback"]
  end

  subgraph DatabaseLane["Database / Storage Swimlane"]
    DB0[("users")]
    DB1[("refresh_tokens")]
    DB2[("candidates")]
    DB3[("uploaded_documents")]
    DB4[("job_descriptions")]
    DB5[("celery_tasks")]
    DB6[("assessments")]
    DB7[("assessment_applications")]
    DB8[("question_sets")]
    DB9[("questions")]
    DB10[("test_sessions")]
    DB11[("answers")]
    DB12[("assessment_progress")]
    DB13[("question_feedback")]
    DB14[("session_feedback")]
    DB15[("learning_paths")]
    DB16[("S3 / MinIO files")]
    DB17[("RAG FAISS and chunk files")]
    DB18[("Course Excel and FAISS index")]
  end

  U0 --> FE0
  FE0 --> FE1
  FE1 -->|No token| FE2
  FE2 --> BE0 --> BE1 --> BE2 --> BE3
  BE3 -->|No| BE20 --> FE9 --> FE10
  BE3 -->|Yes| BE4 --> BE5 --> DB1
  BE5 --> BE6 --> DB0
  BE6 --> FE3
  FE3 --> FE4
  FE1 -->|Token present| FE4 --> BE7
  BE7 -->|Invalid or expired| BE20 --> FE9 --> FE10
  BE7 -->|Valid| BE8
  BE8 -->|Forbidden| BE20

  AD0 --> FE2
  AD1 --> FE5 --> BE9 --> DB2
  DB2 -->|duplicate email| BE20
  AD2 --> FE5 --> BE10
  BE10 --> AI0
  AI0 -->|unsupported type / unreadable text| BE20
  AI0 --> AI1 --> AI2
  AI2 -->|No| AI3 --> AI2
  AI3 -->|Still invalid| AI4 --> AI5
  AI2 -->|Yes| AI5 --> FE5
  AD5 --> BE11 --> AI0 --> AI8 --> DB17
  BE11 --> DB16
  BE11 --> DB5
  AD4 --> FE5 --> BE12
  BE12 -->|missing skills or missing JD text| BE20
  BE12 --> AI6
  AI6 --> AI7
  AI7 -->|Yes| AI8 --> AI10
  AI7 -->|No| AI9 --> AI10
  AI10 --> AI11
  AI11 -->|No| AI9 --> AI10
  AI11 -->|Yes| AI12 --> DB8
  AI12 --> DB9
  BE12 --> DB6
  BE12 -->|candidate supplied| DB7
  BE12 -->|clear cache| FE5
  AD7 --> BE12 --> DB6

  U2 --> FE4 --> BE21
  BE21 --> DB0
  BE21 --> DB2
  BE21 --> DB6
  BE21 --> DB7
  BE21 --> DB10
  U3 --> FE6 --> BE13
  BE13 -->|unpublished / inactive / expired| BE20
  BE13 --> DB6
  BE13 --> DB9
  U4 --> FE6 --> BE12 --> DB7
  U5 --> FE6 --> BE14
  BE14 --> DB8
  BE14 --> DB9
  BE14 -->|no questions| BE20
  BE14 --> DB10
  DB10 --> FE7
  U6 --> FE7
  FE7 --> BE16 --> DB12
  BE16 -->|DB failure| BE20
  U8 --> BE15
  BE15 --> DB10
  BE15 --> DB9
  BE15 -->|invalid session or duplicate completion| BE20
  BE15 -->|invalid answer| BE20
  BE15 --> DB11
  BE15 --> DB10
  BE15 --> DB0
  BE15 --> FE8
  U9 --> FE8
  U10 --> BE18
  BE18 -->|session incomplete| BE20
  BE18 --> DB10
  BE18 --> DB11
  BE18 --> DB9
  BE18 --> AI16
  AI16 --> AI17
  AI17 -->|Yes| AI18 --> DB18
  AI17 -->|No| AI19 --> DB18
  AI18 --> AI19
  AI19 --> FE8
  U11 --> FE8

  AD8 --> BE17 --> DB10
  BE17 --> DB11
  BE17 --> DB9
  BE17 --> DB14
  AD9 --> BE17 --> DB11
  BE17 --> DB10
  AD10 --> BE17 --> AI13
  AI13 --> AI14
  AI14 -->|No| AI15 --> DB14
  AI14 -->|Yes| DB14
  AD11 --> BE19 --> DB15
  AD12 --> BE0 --> DB0
  AD12 --> DB2
  AD12 --> DB6
  AD12 --> DB10
```

### End-to-End Workflow Notes

- Authentication starts at the frontend login route and ends with JWT access and refresh tokens stored in browser local storage.
- Backend route protection is based on JWT validation and admin email checks.
- Candidate registration in the implemented backend is admin-provisioned through the candidate API. Azure SSO can create or update a `User`, but OTP verification is currently unavailable unless Redis-backed OTP state is restored.
- Assessment generation is admin-driven. The admin extracts skills, configures question counts and policies, optionally uploads a RAG document, and then creates an assessment.
- Question generation supports technical and non-technical role flows. Technical flows generate MCQ, coding, and architecture questions. Non-technical flows generate MCQ and reasoning/scenario questions.
- Assessment submission stores answers and session aggregates. MCQs are auto-scored; long-form/coding/architecture/scenario answers are stored and can be reviewed or manually scored by admins.
- Learning path generation analyzes completed sessions, weak topics, assessment skills, and incorrect answers, then recommends courses from FAISS and Excel catalog search.
- Completion tracking exists through `TestSession.is_completed`, `AssessmentApplication.status`, and `LearningPath` records. A dedicated certificate issuance module is not present in the current backend.

## Module-Wise Diagrams

### A. Authentication Flow

```mermaid
flowchart TD
  subgraph User["User / Admin"]
    A0["Open /login"]
    A1["Enter email and password"]
    A2["Optional Azure SSO login"]
    A3["Logout"]
    A4["Registration / candidate provisioning"]
  end

  subgraph Frontend["Frontend"]
    F0["ProtectedAuthRoute"]
    F1["LoginContainer"]
    F2["authService.login"]
    F3["Store authToken, refreshToken, loggedInUser, role, candidate_id"]
    F4["Axios interceptor attaches Bearer token"]
    F5["AdminProtectedRoute / ProtectedRoute"]
    F6["401 interceptor clears localStorage"]
    F7["AdminAddCandidate / SignUp route"]
  end

  subgraph Backend["Backend"]
    B0["POST /api/v1/auth/login"]
    B1{"Email is default admin?"}
    B2["Validate default admin password"]
    B3["Lookup active Candidate by email"]
    B4["Verify bcrypt or legacy candidate password"]
    B5{"Authenticated?"}
    B6["Get or create User"]
    B7["Update login streak"]
    B8["Create access and refresh JWT"]
    B9["Persist refresh token"]
    B10["Return token response with role"]
    B11["GET /api/v1/auth/sso/azure/login"]
    B12["GET /api/v1/auth/sso/azure/callback"]
    B13["Validate Azure identity and allowed domain"]
    B14["POST /api/v1/auth/refresh"]
    B15["Validate refresh JWT and DB token"]
    B16["Revoke old refresh token and issue new pair"]
    B17["POST /api/v1/auth/logout"]
    B18["Revoke refresh token"]
    B19["POST /api/v1/auth/request-otp"]
    B20["POST /api/v1/auth/verify-otp"]
    B21["Return 503 when Redis OTP state is unavailable"]
    B22["POST /api/v1/candidates"]
    B23["Hash password and create Candidate"]
  end

  subgraph DB["Database"]
    D0[("users")]
    D1[("candidates")]
    D2[("refresh_tokens")]
  end

  subgraph External["External Auth / Messaging"]
    E0["Azure AD"]
    E1["Brevo SMTP via Celery email task"]
    E2["Redis for OTP state - currently disabled in code path"]
  end

  A0 --> F0 --> F1 --> A1 --> F2 --> B0
  B0 --> B1
  B1 -->|Yes| B2 --> B5
  B1 -->|No| B3 --> D1
  B3 --> B4 --> B5
  B5 -->|No| F6
  B5 -->|Yes| B6 --> D0
  B6 --> B7 --> D0
  B7 --> B8 --> B9 --> D2
  B9 --> B10 --> F3 --> F4 --> F5
  F5 -->|candidate| F4
  F5 -->|admin| F4
  F5 -->|role mismatch| F6

  A2 --> B11 --> E0 --> B12 --> B13
  B13 -->|invalid provider/domain| F6
  B13 -->|valid| B6

  F4 -->|access token expired| B14 --> B15 --> D2
  B15 -->|invalid/revoked/expired| F6
  B15 -->|valid| B16 --> D2 --> F3

  A3 --> B17 --> B18 --> D2 --> F6

  A4 --> F7 --> B22 --> B23 --> D1

  B19 --> E1
  B20 --> E2
  E2 -->|not available in current code path| B21
```

Authentication is implemented with JWT access tokens and persisted refresh tokens. Admin authorization is email-based. Candidate login uses admin-created candidate credentials. Azure SSO endpoints exist for Nagarro-domain users. OTP request sends email, but OTP verification currently returns service unavailable because Redis OTP storage is disabled.

### B. Learner Journey

```mermaid
flowchart TD
  subgraph Learner["Learner"]
    L0["Login"]
    L1["Dashboard access"]
    L2["View pending assessments"]
    L3["Open assessment link or assignment"]
    L4["Submit screening responses"]
    L5["Start quiz"]
    L6["Answer questions"]
    L7["Pause / resume"]
    L8["Submit"]
    L9["View score and feedback"]
    L10["Generate or view learning path"]
    L11["Consume courses"]
  end

  subgraph Frontend["Frontend"]
    F0["ProtectedRoute"]
    F1["DashboardContainer"]
    F2["AssessmentsListContainer"]
    F3["CandidateAssessmentContainer"]
    F4["QuizContainer"]
    F5["assessmentProgressService"]
    F6["DetailedResults / Result UI"]
    F7["EmployeeLearningPath"]
  end

  subgraph Backend["Backend"]
    B0["GET /api/v1/dashboard"]
    B1["GET /api/v1/candidates/my-pending-assessments"]
    B2["GET /api/v1/candidates/my-assessments"]
    B3["GET /api/v1/assessments/{assessment_id}"]
    B4{"Assessment available?"}
    B5["POST /api/v1/assessments/{assessment_id}/screening-responses"]
    B6["POST /api/v1/questionset-tests/start"]
    B7["POST /api/v1/questionset-tests/start/anonymous"]
    B8{"QuestionSet has questions?"}
    B9["Create TestSession"]
    B10["POST /api/v1/assessment-progress/save"]
    B11["GET /api/v1/assessment-progress/load/{email}"]
    B12["POST /api/v1/questionset-tests/submit"]
    B13["POST /api/v1/questionset-tests/submit/anonymous"]
    B14{"Session valid and not completed?"}
    B15{"Answers valid?"}
    B16["Persist Answers and calculate score"]
    B17["Update quiz streak"]
    B18["GET /api/v1/questionset-tests/{session_id}/results"]
    B19["GET /api/v1/learning-path/{session_id}"]
    B20{"Session completed?"}
    B21["POST /api/v1/learning-path/self"]
    B22["GET /api/v1/learning-path/employee"]
    B23["Return HTTP error"]
  end

  subgraph AI["AI / Recommendation"]
    AI0["Weak topic extraction from wrong answers"]
    AI1["Course recommendation search"]
    AI2{"FAISS available?"}
    AI3["FAISS semantic search"]
    AI4["Excel keyword fallback"]
    AI5["Merge and dedupe recommendations"]
  end

  subgraph DB["Database"]
    D0[("users")]
    D1[("candidates")]
    D2[("assessments")]
    D3[("assessment_applications")]
    D4[("screening_responses")]
    D5[("question_sets")]
    D6[("questions")]
    D7[("test_sessions")]
    D8[("answers")]
    D9[("assessment_progress")]
    D10[("session_feedback")]
    D11[("learning_paths")]
    D12[("course catalog")]
  end

  L0 --> F0
  L1 --> F1 --> B0 --> D0
  L2 --> F2 --> B1 --> D1
  B1 --> D3
  B1 --> D2
  L3 --> F3 --> B3 --> D2
  B3 --> B4
  B4 -->|No: unpublished, inactive, expired| B23
  B4 -->|Yes| D6 --> F3
  L4 --> F3 --> B5 --> D4
  L5 --> F4 --> B6
  L5 --> F4 --> B7
  B6 --> D5
  B7 --> D5
  B6 --> D6
  B7 --> D6
  B6 --> B8
  B7 --> B8
  B8 -->|No| B23
  B8 -->|Yes| B9 --> D7 --> F4
  L6 --> F4
  L7 --> F5 --> B10 --> D9
  F5 --> B11 --> D9
  L8 --> F4 --> B12
  L8 --> F4 --> B13
  B12 --> B14
  B13 --> B14
  B14 -->|No| B23
  B14 -->|Yes| B15
  B15 -->|No| B23
  B15 -->|Yes| B16 --> D8
  B16 --> D7
  B16 --> B17 --> D0
  B16 --> F6
  L9 --> F6 --> B18 --> D7
  B18 --> D8
  B18 --> D10
  L10 --> F7 --> B19
  B19 --> B20
  B20 -->|No| B23
  B20 -->|Yes| D7
  B19 --> D8
  B19 --> AI0 --> AI1 --> AI2
  AI2 -->|Yes| AI3 --> D12
  AI2 -->|No| AI4 --> D12
  AI3 --> AI4
  AI4 --> AI5 --> F7
  F7 --> B21 --> D11
  F7 --> B22 --> D11
  L11 --> F7
```

The learner journey includes dashboard statistics, pending assessment discovery, screening responses, question-set test sessions, auto-save/load progress, submission, result viewing, and learning path retrieval. Progress is stored per candidate email, while final assessment state is stored on `test_sessions` and `answers`.

### C. Admin Journey

```mermaid
flowchart TD
  subgraph Admin["Admin"]
    A0["Login"]
    A1["Open admin dashboard"]
    A2["Create candidate"]
    A3["Upload JD, resume, requirements, or question doc"]
    A4["Extract skills and role"]
    A5["Configure assessment"]
    A6["Add manual questions and screening questions"]
    A7["Generate and publish assessment"]
    A8["View assessment and candidates"]
    A9["Review submitted results"]
    A10["Override scoring"]
    A11["Generate and publish feedback"]
    A12["Generate learning path"]
    A13["Push learning path to employee"]
    A14["Monitor assigned learning paths and stats"]
  end

  subgraph Frontend["Frontend Admin Routes"]
    F0["AdminProtectedRoute"]
    F1["AdminDashboard"]
    F2["AdminAddCandidate"]
    F3["AdminCandidateList"]
    F4["AssessmentSetupContainer"]
    F5["AdminAssessmentLandingContainer"]
    F6["AssessmentViewContainer"]
    F7["DetailedResultsView"]
    F8["LearningPathContainer"]
    F9["AdminLearningPathsContainer"]
  end

  subgraph Backend["Backend Admin APIs"]
    B0["admin_required / check_admin"]
    B1["GET /api/v1/admin/stats"]
    B2["POST /api/v1/candidates"]
    B3["PATCH/PUT /api/v1/candidates/{candidate_id}"]
    B4["POST /api/v1/admin/extract-skills"]
    B5["POST /api/v1/admin/extract-skills-candidate"]
    B6["POST /api/v1/admin/extract-role"]
    B7["POST /api/v1/admin/question-docs/upload"]
    B8["POST /api/v1/assessments"]
    B9["PUT /api/v1/assessments/{assessment_id}/metadata"]
    B10["POST /api/v1/assessments/{assessment_id}/publish"]
    B11["GET /api/v1/assessments/with-questions"]
    B12["GET /api/v1/admin/assessment-results/{assessment_id}/results"]
    B13["GET /api/v1/admin/assessment-results/session/{session_id}"]
    B14["PATCH /api/v1/admin/assessment-results/session/{session_id}/answer/{question_id}"]
    B15["POST /api/v1/admin/assessment-results/session/{session_id}/feedback/generate"]
    B16["PUT /api/v1/admin/assessment-results/session/{session_id}/feedback"]
    B17["POST /api/v1/learning-path/push-to-employee"]
    B18["GET /api/v1/learning-path/admin/employees"]
    B19["GET /api/v1/learning-path/admin/employee/{email}"]
    B20{"Admin authorized?"}
    B21["Return 403"]
  end

  subgraph AI["AI Services"]
    AI0["Skill Intelligence"]
    AI1["Question Generator"]
    AI2["RAG Ingestion"]
    AI3["Session Feedback Generator"]
    AI4["Course Recommendation"]
  end

  subgraph DB["Database / Storage"]
    D0[("users")]
    D1[("candidates")]
    D2[("uploaded_documents")]
    D3[("job_descriptions")]
    D4[("question_sets")]
    D5[("questions")]
    D6[("assessments")]
    D7[("assessment_applications")]
    D8[("test_sessions")]
    D9[("answers")]
    D10[("session_feedback")]
    D11[("learning_paths")]
    D12[("S3 / MinIO")]
    D13[("RAG index files")]
  end

  A0 --> F0 --> B0 --> B20
  B20 -->|No| B21
  B20 -->|Yes| F1
  A1 --> F1 --> B1 --> D0
  B1 --> D3
  B1 --> D5
  B1 --> D8
  A2 --> F2 --> B2 --> D1
  F3 --> B3 --> D1
  A3 --> F4 --> B4 --> AI0
  A3 --> F4 --> B5 --> AI0
  A4 --> F4 --> B6 --> AI0
  B4 --> D2
  B5 --> D2
  B4 --> D12
  A3 --> F4 --> B7 --> AI2 --> D13
  B7 --> D12
  A5 --> F4 --> B8
  A6 --> F4 --> B8
  B8 --> AI1 --> D4
  AI1 --> D5
  B8 --> D6
  B8 --> D7
  A7 --> F4 --> B10 --> D6
  A8 --> F5 --> B11 --> D6
  B11 --> D5
  A8 --> F6 --> B11
  A9 --> F7 --> B12 --> D8
  B12 --> D9
  B12 --> D10
  F7 --> B13 --> D8
  A10 --> F7 --> B14 --> D9
  B14 --> D8
  A11 --> F7 --> B15 --> AI3 --> D10
  F7 --> B16 --> D10
  A12 --> F8 --> AI4
  A13 --> F8 --> B17 --> D11
  A14 --> F9 --> B18 --> D11
  F9 --> B19 --> D11
```

Admins provision candidates, extract skills, create assessments, publish assignments, inspect results, adjust scoring, generate feedback, and push finalized learning paths. The admin flow is protected by JWT plus email-based admin checks.

### D. AI-Powered Features

```mermaid
flowchart TD
  subgraph Inputs["Inputs"]
    I0["Resume / CV"]
    I1["Job Description"]
    I2["Requirements / Specifications"]
    I3["Question source document"]
    I4["Assessment result and answers"]
    I5["Weak topics and score"]
  end

  subgraph Parsing["Parsing and Extraction"]
    P0["Validate extension and size"]
    P1["Extract PDF text with pdfplumber"]
    P2["Extract DOCX text with python-docx"]
    P3["Extract PPT/PPTX text"]
    P4["Extract TXT text"]
    P5{"Readable text?"}
  end

  subgraph SkillAI["Skill Intelligence"]
    S0["Build semantic extraction prompt"]
    S1["OpenAI Chat LLM"]
    S2{"Valid JSON and enough confidence?"}
    S3["Retry with repair instruction"]
    S4["Fallback regex / dictionary extractor"]
    S5["Normalize aliases, levels, source, priority"]
    S6["Merge JD and resume matches"]
    S7["Return role, role_type, seniority, skills, confidence"]
  end

  subgraph QuestionAI["Assessment Generation"]
    Q0["Build required skill plan"]
    Q1["Infer or accept role_type"]
    Q2["Allocate MCQ / coding / architecture / reasoning"]
    Q3["Apply RAG/LLM generation policy"]
    Q4{"RAG doc_id and chunks available?"}
    Q5["Retrieve isolated document chunks"]
    Q6["Generate document-grounded batch"]
    Q7["Generate LLM-only batch"]
    Q8{"Strict JSON parses and count matches?"}
    Q9["Retry/fallback affected RAG batch to LLM"]
    Q10["Persist questions with source metadata"]
  end

  subgraph FeedbackAI["Feedback Generation"]
    G0["Build session feedback prompt"]
    G1["OpenAI Chat LLM"]
    G2{"LLM success?"}
    G3["Use generated draft"]
    G4["Use deterministic fallback summary"]
    G5["Admin edits and publishes"]
  end

  subgraph CourseAI["Learning Path Recommendation"]
    C0["Derive weak topics from wrong answers"]
    C1["Determine learner level from score"]
    C2["FAISS course vector search"]
    C3["Excel catalog keyword search"]
    C4["Detect stale or missing index"]
    C5["Merge, dedupe, and filter by course level"]
  end

  subgraph Outputs["Outputs"]
    O0["ExtractedSkill list"]
    O1["Role metadata"]
    O2["Generated QuestionSet"]
    O3["SessionFeedback draft/published feedback"]
    O4["Recommended course list"]
  end

  I0 --> P0
  I1 --> P0
  I2 --> P0
  I3 --> P0
  P0 -->|invalid| X0["422 or 400 error"]
  P0 --> P1
  P0 --> P2
  P0 --> P3
  P0 --> P4
  P1 --> P5
  P2 --> P5
  P3 --> P5
  P4 --> P5
  P5 -->|No| X1["Text extraction error"]
  P5 -->|Yes| S0

  S0 --> S1 --> S2
  S2 -->|No| S3 --> S2
  S3 -->|Still no| S4 --> S5
  S2 -->|Yes| S5
  S5 --> S6 --> S7
  S7 --> O0
  S7 --> O1

  S7 --> Q0 --> Q1 --> Q2 --> Q3 --> Q4
  I3 --> Q4
  Q4 -->|Yes| Q5 --> Q6 --> Q8
  Q4 -->|No| Q7 --> Q8
  Q8 -->|No| Q9 --> Q7
  Q8 -->|Yes| Q10 --> O2

  I4 --> G0 --> G1 --> G2
  G2 -->|Yes| G3 --> G5 --> O3
  G2 -->|No| G4 --> G5 --> O3

  I5 --> C0 --> C1
  C1 --> C4
  C4 -->|usable| C2
  C4 -->|missing/stale| C3
  C2 --> C3 --> C5 --> O4
```

The AI layer uses LLM-first strategies where the result needs semantic reasoning, but it keeps deterministic fallbacks for resilience. Skill extraction falls back to regex/dictionary matching. RAG question generation falls back batch-by-batch to LLM-only generation. Session feedback falls back to a rule-based summary.

### E. Assessment Flow

```mermaid
flowchart TD
  subgraph Admin["Admin"]
    A0["Configure assessment"]
    A1["Set skills and levels"]
    A2["Set question counts"]
    A3["Set RAG policy"]
    A4["Add manual questions"]
    A5["Add screening questions"]
    A6["Publish"]
  end

  subgraph Backend["Backend"]
    B0["POST /api/v1/assessments"]
    B1{"Admin user?"}
    B2{"required_skills present?"}
    B3{"JD id supplied?"}
    B4["Fetch JobDescription text"]
    B5{"JD text available?"}
    B6["Create or update Candidate from candidate_info"]
    B7["Derive difficulty distribution"]
    B8["Infer role_type if not explicit"]
    B9["Call generate_assessment_question_set"]
    B10["Add manual questions"]
    B11["Store screening questions in description JSON"]
    B12["Create Assessment"]
    B13["Create AssessmentApplication when candidate provided"]
    B14["Clear assessment cache"]
    B15["Return AssessmentResponse"]
    B16["Return HTTP error"]
  end

  subgraph Generator["Question Generator"]
    G0["Normalize skill levels"]
    G1["Calculate type counts"]
    G2["Allocate RAG and LLM counts"]
    G3["Collect RAG context"]
    G4{"Context found?"}
    G5["Generate MCQ batch"]
    G6["Generate coding batch"]
    G7["Generate architecture batch"]
    G8["Generate reasoning/scenario batch"]
    G9{"Output valid JSON with expected count?"}
    G10["Fallback RAG batch to LLM"]
    G11["Create QuestionSet"]
    G12["Create Question records"]
  end

  subgraph Learner["Learner"]
    L0["Open assessment"]
    L1["Start session"]
    L2["Submit answers"]
    L3["View result"]
  end

  subgraph Runtime["Runtime APIs"]
    R0["GET /api/v1/assessments/{assessment_id}"]
    R1{"Published, active, not expired?"}
    R2["POST /api/v1/questionset-tests/start"]
    R3["Create TestSession"]
    R4["POST /api/v1/questionset-tests/submit"]
    R5{"Valid session and answers?"}
    R6["Create Answer records"]
    R7["Score MCQs"]
    R8["Store long-form answers as not auto-correct"]
    R9["Finalize TestSession"]
    R10["GET results"]
  end

  subgraph DB["Database"]
    D0[("job_descriptions")]
    D1[("candidates")]
    D2[("question_sets")]
    D3[("questions")]
    D4[("assessments")]
    D5[("assessment_applications")]
    D6[("test_sessions")]
    D7[("answers")]
  end

  A0 --> B0 --> B1
  B1 -->|No| B16
  B1 -->|Yes| B2
  B2 -->|No| B16
  B2 -->|Yes| B3
  B3 -->|Yes| B4 --> D0 --> B5
  B5 -->|No| B16
  B5 -->|Yes| B6
  B3 -->|No| B6
  B6 --> D1
  B6 --> B7 --> B8 --> B9
  B9 --> G0 --> G1 --> G2 --> G3 --> G4
  G4 -->|Yes| G5
  G4 -->|No| G10
  G5 --> G9
  G6 --> G9
  G7 --> G9
  G8 --> G9
  G9 -->|No| G10
  G10 --> G5
  G9 -->|Yes| G11 --> D2
  G11 --> G12 --> D3
  B9 --> B10 --> D3
  B10 --> B11 --> B12 --> D4
  B12 --> B13 --> D5
  B12 --> B14 --> B15
  A6 --> B15

  L0 --> R0 --> D4 --> R1
  R1 -->|No| B16
  R1 -->|Yes| D3
  L1 --> R2 --> D2
  R2 --> D3
  R2 --> R3 --> D6
  L2 --> R4 --> R5
  R5 -->|No| B16
  R5 -->|Yes| R6 --> D7
  R6 --> R7
  R6 --> R8
  R7 --> R9 --> D6
  R8 --> R9
  L3 --> R10 --> D6
  R10 --> D7
```

The assessment lifecycle has two halves: admin-time generation and learner-time execution. Admin-time generation persists question sets and questions. Learner-time execution creates sessions and answers, calculates MCQ scores, and leaves long-form evaluation available for admin review.

### F. Data Flow

```mermaid
flowchart LR
  subgraph Frontend["Frontend"]
    F0["React components"]
    F1["services.ts API methods"]
    F2["Axios interceptors"]
    F3["Local storage tokens"]
    F4["GET cache"]
  end

  subgraph Backend["Backend"]
    B0["FastAPI route"]
    B1["Dependency injection"]
    B2["Auth and admin validation"]
    B3["Pydantic request validation"]
    B4["Business logic / service call"]
    B5["SQLAlchemy session"]
    B6["Exception handlers"]
  end

  subgraph AI["AI Services"]
    AI0["OpenAI Chat"]
    AI1["Skill Intelligence"]
    AI2["Question Generation"]
    AI3["Feedback Generation"]
    AI4["Course FAISS / Excel Search"]
  end

  subgraph Database["Database"]
    D0[("PostgreSQL")]
    D1[("Users")]
    D2[("Candidates")]
    D3[("Documents")]
    D4[("Assessments")]
    D5[("Questions")]
    D6[("Sessions")]
    D7[("Answers")]
    D8[("Learning Paths")]
  end

  subgraph Storage["External / File Storage"]
    S0[("S3 / MinIO")]
    S1[("FAISS index files")]
    S2[("Course Excel")]
    S3[("Redis / Celery")]
  end

  F0 --> F1 --> F2
  F2 -->|Authorization: Bearer token| B0
  F3 --> F2
  F4 -->|cache hit for GET| F0
  B0 --> B1 --> B2
  B2 -->|401 or 403| B6 --> F2
  B2 -->|allowed| B3
  B3 -->|422 validation error| B6 --> F2
  B3 --> B4
  B4 -->|LLM task| AI0
  B4 -->|skill extraction| AI1 --> AI0
  B4 -->|assessment generation| AI2 --> AI0
  B4 -->|feedback generation| AI3 --> AI0
  B4 -->|course recommendation| AI4 --> S1
  AI4 --> S2
  B4 -->|file upload/download| S0
  B4 -->|task status/email/OTP where configured| S3
  B4 --> B5 --> D0
  D0 --> D1
  D0 --> D2
  D0 --> D3
  D0 --> D4
  D0 --> D5
  D0 --> D6
  D0 --> D7
  D0 --> D8
  B5 -->|commit success| B0 --> F2 --> F0
  B5 -->|rollback on failure| B6 --> F2
```

All normal data movement starts in React components, flows through typed API service methods, and reaches FastAPI routes through Axios. FastAPI dependencies validate JWT and role requirements before service logic touches AI, storage, or PostgreSQL.

### G. Error Handling and Retry Paths

```mermaid
flowchart TD
  subgraph Client["Frontend Error Handling"]
    C0["API request"]
    C1{"Status 401?"}
    C2["Clear localStorage"]
    C3["Redirect to /login"]
    C4["Show form/API error"]
    C5["Clear GET cache after mutations"]
  end

  subgraph Backend["Backend Error Handling"]
    B0["Request middleware"]
    B1["Pydantic validation"]
    B2["Auth dependency"]
    B3["Admin dependency"]
    B4["Business operation"]
    B5["DB commit"]
    B6["HTTPException handler"]
    B7["ValidationError handler"]
    B8["General exception handler"]
  end

  subgraph Retry["Retry / Fallback Mechanisms"]
    R0["Skill LLM extraction"]
    R1["Retry JSON repair"]
    R2["Regex fallback extractor"]
    R3["RAG question generation"]
    R4["Fallback affected batch to LLM-only"]
    R5["Session feedback LLM"]
    R6["Fallback deterministic feedback"]
    R7["Course vector search"]
    R8["Excel catalog fallback"]
    R9["S3 upload TypeError compatibility call"]
  end

  subgraph FailureTypes["Common Failure Types"]
    F0["Invalid credentials"]
    F1["Invalid/expired token"]
    F2["Role forbidden"]
    F3["Unsupported or oversized file"]
    F4["Text extraction failure"]
    F5["Missing required skills"]
    F6["Unpublished/inactive/expired assessment"]
    F7["Invalid session or duplicate submit"]
    F8["Invalid answer payload"]
    F9["LLM unavailable or invalid JSON"]
    F10["DB error"]
  end

  C0 --> B0 --> B1
  B1 -->|invalid request| B7 --> C4
  B1 --> B2
  B2 -->|invalid token| B6 --> C1
  C1 -->|Yes| C2 --> C3
  C1 -->|No| C4
  B2 --> B3
  B3 -->|not admin| B6 --> C4
  B3 --> B4
  B4 -->|known failure| B6 --> C4
  B4 --> B5
  B5 -->|commit failure| B8 --> C4
  B5 -->|success| C5

  R0 -->|invalid JSON / low confidence| R1 --> R0
  R1 -->|still failed| R2
  R3 -->|missing context or bad JSON| R4
  R5 -->|exception| R6
  R7 -->|missing/stale index or vector exception| R8
  R9 -->|alternate storage signature| B4

  F0 --> B6
  F1 --> B6
  F2 --> B6
  F3 --> B6
  F4 --> B6
  F5 --> B6
  F6 --> B6
  F7 --> B6
  F8 --> B6
  F9 --> R1
  F10 --> B8
```

The app combines explicit HTTP errors for expected business failures with framework-level exception handlers for validation and unhandled failures. AI-facing flows have graceful fallbacks so a single LLM or vector retrieval issue does not necessarily block the whole workflow.

## Key Backend Modules

- `BE/app/main.py`: FastAPI setup, middleware, exception handlers, router registration, health and metrics endpoints.
- `BE/app/api/auth.py`: login, Azure SSO, refresh, logout, OTP request/disabled verification.
- `BE/app/core/security.py`: JWT, password hashing, admin email checks.
- `BE/app/core/dependencies.py`: current user, optional auth, admin-required dependencies.
- `BE/app/api/candidates.py`: candidate provisioning, profile updates, pending assessments, file links, skill overrides.
- `BE/app/api/assessments.py`: assessment CRUD, question generation orchestration, publishing, applications, screening responses.
- `BE/app/api/questionset_tests.py`: start/submit question-set tests, anonymous flow, result retrieval, question feedback.
- `BE/app/api/assessment_results.py`: admin result review, answer overrides, LLM feedback, sharing, candidate status updates.
- `BE/app/api/admin_skill_extraction.py`: document skill and role extraction for admin and candidate flows.
- `BE/app/services/skill_intelligence.py`: LLM-first semantic skill extraction with validation, normalization, retries, and fallback.
- `BE/app/utils/generate_admin_assessment.py`: RAG/LLM assessment generation and question persistence.
- `BE/app/services/doc_ingest.py`: isolated document chunking, FAISS indexing, lexical fallback, cleanup.
- `BE/app/api/learning_path.py`: weak-topic analysis, course recommendation, self-save, admin push, assigned learning paths.
- `BE/app/api/recommended_courses.py` and `BE/app/services/course_catalog.py`: course FAISS search and Excel fallback search.
- `BE/app/db/models.py`: PostgreSQL model definitions for users, candidates, assessments, questions, sessions, answers, feedback, progress, and learning paths.

## Current Implementation Notes

- Certificate issuance is not implemented as a separate module. Completion can be tracked from `TestSession.is_completed`, `score_percentage`, `AssessmentApplication.status`, and assigned `LearningPath` records.
- OTP verification currently returns `503 Service Unavailable` because Redis-backed OTP storage is disabled in the active auth code path.
- Long-form coding, architecture, and scenario answers are stored and initially marked not auto-correct. Admin review can override correctness and recalculate the session score.
- RAG question generation is request-scoped by `doc_id`, and temporary RAG indexes are cleaned after assessment generation.
- Course recommendations remain available even when the FAISS index is missing or stale because the Excel catalog fallback is always searched.
